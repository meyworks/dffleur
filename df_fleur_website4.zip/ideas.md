# DF FLEUR - Design Philosophy

## Brand Essence
**Positioning:** An upscale restaurant and café that blends sophistication with warmth—a sanctuary for refined dining and premium coffee culture in Cairo's Heliopolis district.

**Personality:** Elegant, Welcoming, Refined

---

## Design Movement
**Neo-Luxury Minimalism with Organic Warmth**

A design language that combines the restraint and sophistication of minimalism with the sensory richness of luxury hospitality. The aesthetic draws from contemporary luxury hospitality design, emphasizing negative space, premium materials (implied through color and texture), and carefully curated moments of visual delight.

---

## Core Principles

1. **Intentional Restraint:** Every element serves a purpose. Whitespace is a design material, not emptiness. Avoid clutter; let premium content breathe.

2. **Tactile Sophistication:** Subtle textures, soft shadows, and refined gradients create depth without visual noise. The interface should feel like touching quality materials.

3. **Narrative Flow:** The website tells a story—from discovery (hero) through exploration (menu, offers) to connection (contact). Each page transitions smoothly into the next.

4. **Warmth in Precision:** While minimalist, the design is never cold. Warm color accents, generous spacing, and human-centered typography create approachability within sophistication.

---

## Color Philosophy

**Primary Palette:**
- **Signature Black:** `#1a1a1a` (off-black, not pure black—warmer, more refined)
- **Cream/Off-White:** `#f8f7f4` (warm ivory, evoking premium paper and luxury hospitality)
- **Gold Accent:** `#d4af37` (subtle, used sparingly for luxury moments—crown logo, highlights)
- **Warm Taupe:** `#a89968` (secondary accent, grounds the palette, appears in borders and subtle backgrounds)
- **Deep Charcoal:** `#3a3a3a` (for text on light backgrounds, softer than pure black)

**Emotional Intent:** The palette evokes timeless luxury—think high-end restaurants in Paris or Cairo's finest establishments. Gold is used as a signature accent (never overused), while the warm neutrals create an inviting, sophisticated atmosphere.

---

## Layout Paradigm

**Asymmetric, Intentional Spacing**

- **Hero Section:** Full-width image with overlay gradient, text positioned off-center (left-aligned or right-aligned, never centered). Crown logo integrated into the design.
- **Content Sections:** Alternating left-right layouts with generous margins. Text on one side, imagery or whitespace on the other.
- **Menu Display:** Grid-based but with varied card sizes and asymmetric arrangements to avoid monotony.
- **Navigation:** Minimalist top nav with logo and sparse menu items. Sticky on scroll, subtle background transition.

---

## Signature Elements

1. **Crown Logo Integration:** The DF FLEUR crown appears as a watermark or subtle accent throughout the site. It's the brand's visual anchor.

2. **Flipping Menu Cards:** The interactive menu uses a 3D flip animation on hover/click. Cards reveal item details on flip, creating a tactile, engaging experience.

3. **Gradient Overlays:** Subtle linear gradients (often from dark to transparent) appear over images to ensure text legibility and add sophistication.

4. **Serif Typography for Headlines:** A refined serif font (e.g., Playfair Display) for main headings contrasts with a clean sans-serif (e.g., Poppins) for body text, creating visual hierarchy.

---

## Interaction Philosophy

**Fluid, Purposeful Motion**

- **Hover Effects:** Subtle scale (1.02–1.05), shadow depth increase, or color shift on interactive elements.
- **Page Transitions:** Smooth fade-ins or slide-ins as sections come into view. No jarring animations.
- **Menu Flip Animation:** 3D flip with a 600ms duration, easing function that feels natural (cubic-bezier(0.68, -0.55, 0.265, 1.55) for a slight bounce).
- **Scroll Triggers:** Elements fade in or slide up as users scroll, creating a sense of discovery.

---

## Animation Guidelines

- **Entrance Animations:** Elements fade in and slide up (20–30px) over 600–800ms as they come into view.
- **Interactive Feedback:** Buttons scale to 0.98 on click (100ms), creating tactile feedback.
- **Menu Flip:** 3D perspective flip with 600ms duration. On hover, the card lifts slightly (shadow deepens).
- **Smooth Scrolling:** All scroll-based animations use `prefers-reduced-motion` media query for accessibility.
- **Micro-interactions:** Hover states on links include a subtle underline animation or color shift (200ms).

---

## Typography System

**Font Pairing:**
- **Headlines:** Playfair Display (serif, 700 weight) – elegant, timeless, luxury-forward
- **Subheadings:** Poppins (sans-serif, 600 weight) – modern, readable, grounded
- **Body Text:** Poppins (sans-serif, 400 weight) – clean, accessible, professional
- **Accents/Captions:** Poppins (sans-serif, 500 weight, uppercase) – refined, structured

**Hierarchy:**
- **H1:** 56px (Playfair Display, 700, letter-spacing: 0.5px)
- **H2:** 42px (Playfair Display, 700, letter-spacing: 0.3px)
- **H3:** 28px (Poppins, 600)
- **Body:** 16px (Poppins, 400, line-height: 1.6)
- **Small Text:** 14px (Poppins, 400, line-height: 1.5)

---

## Brand Essence (One-Liner)
**DF FLEUR is where Cairo's refined palate discovers premium dining and coffee culture in an atmosphere of understated elegance.**

---

## Brand Voice

**Tone:** Sophisticated yet approachable, inviting yet exclusive.

**Example Headlines:**
- "Discover the Art of Refined Dining" (not "Welcome to Our Restaurant")
- "Every Cup Tells a Story" (not "Great Coffee Here")

**Example CTAs:**
- "Explore Our Menu" (not "Click Here")
- "Reserve Your Moment" (not "Book Now")

**Microcopy:** Warm, descriptive, never generic. Avoid corporate jargon. Focus on sensory details and experience.

---

## Wordmark & Logo

**Logo Concept:** A stylized crown above the text "DF FLEUR" in Playfair Display. The crown is minimal—three points with subtle serifs, rendered in gold (#d4af37) on a transparent background. The wordmark uses the signature black (#1a1a1a).

**Usage:** The logo appears in the header (sticky nav) and as a watermark accent throughout the site. It's never oversized or centered; it's integrated into the design flow.

---

## Signature Brand Color

**Gold (#d4af37)** – Unmistakably DF FLEUR's ownable accent color. Used sparingly for:
- Crown logo
- Hover states on key interactive elements
- Accent borders or dividers
- Call-to-action buttons (secondary style)

This gold is warm, refined, and instantly recognizable as luxury.

---

## Style Decisions (Amendments)

- **Spacing Rhythm:** Use 8px base unit. Margins and padding follow multiples of 8 (8, 16, 24, 32, 48, 64px).
- **Border Radius:** Minimal rounding (4px on cards, 2px on buttons) to maintain sophistication.
- **Shadows:** Soft, layered shadows (e.g., `0 4px 12px rgba(0,0,0,0.1)`) for depth without drama.
- **Responsive Design:** Mobile-first approach. On mobile, reduce font sizes by 10–15% and adjust spacing proportionally.
- **Accessibility:** All text meets WCAG AA contrast ratios. Interactive elements are keyboard-accessible. Animations respect `prefers-reduced-motion`.
