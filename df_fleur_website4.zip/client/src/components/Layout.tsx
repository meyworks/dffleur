import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Menu, X } from "lucide-react";

interface LayoutProps {
  children: React.ReactNode;
}

/**
 * Main layout component with sticky navigation
 * Design: Minimalist luxury nav with logo and sparse menu items
 */
export default function Layout({ children }: LayoutProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { label: "Menu", href: "/menu" },
    { label: "Offers", href: "/offers" },
    { label: "Contact", href: "/contact" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Sticky Navigation */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-background/95 backdrop-blur-sm shadow-luxury border-b border-border"
            : "bg-transparent"
        }`}
      >
        <div className="container flex items-center justify-between h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <img
              src="/manus-storage/logo_crown_cfdb5280.png"
              alt="DF FLEUR"
              className="h-8 w-8"
            />
            <span className="text-xl font-bold tracking-wider hidden sm:inline">
              DF FLEUR
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href} className="text-sm font-medium hover:text-accent transition-colors duration-200 relative group">
                {item.label}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-accent transition-all duration-300 group-hover:w-full" />
              </Link>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 hover:bg-muted rounded-sm transition-colors"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-background border-b border-border">
            <div className="container py-4 flex flex-col gap-4">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className="text-sm font-medium hover:text-accent transition-colors block"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-1 pt-20">{children}</main>

      {/* Footer */}
      <footer className="bg-deep-charcoal text-cream-white mt-20">
        <div className="container py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            {/* Brand */}
            <div>
            <Link href="/" className="flex items-center gap-2 mb-4">
              <img
                src="/manus-storage/logo_crown_cfdb5280.png"
                alt="DF FLEUR"
                className="h-6 w-6"
              />
              <span className="text-lg font-bold">DF FLEUR</span>
            </Link>
              <p className="text-sm text-cream-white/70">
                Premium restaurant and café in Heliopolis, Cairo
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                {navItems.map((item) => (
                  <li key={item.href}>
                    <Link href={item.href} className="hover:text-accent transition-colors">
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h4 className="font-semibold mb-4">Get In Touch</h4>
              <p className="text-sm text-cream-white/70 mb-2">
                📍 24 Mohamed Farid Street, El Nozha, Cairo
              </p>
              <p className="text-sm text-cream-white/70">
                📱 +20 104 000 9755
              </p>
            </div>
          </div>

          <div className="border-t border-cream-white/20 pt-8 text-center text-sm text-cream-white/60">
            <p>&copy; 2026 DF FLEUR. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
