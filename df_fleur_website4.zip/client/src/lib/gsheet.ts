/**
 * Utility to fetch data from Google Sheets published CSV exports
 * This allows the website to pull live data from the Google Sheet
 */

const SHEET_BASE_ID = "2PACX-1vRTB4bIAWk0Bfn3sf8bkSZJMykqjJ0B_lu_d_0Ys0t3ZUCmkRVH4bSkHOTRbu_938q5lgAmF4EqKDSa";

const SHEET_GIDS = {
  Offers: "1626770873",
  MenuCategories: "1954761004",
  MenuItems: "884715003",
  Contact: "1353808229",
};

export type SheetName = keyof typeof SHEET_GIDS;

/**
 * Fetch CSV data from a Google Sheet tab
 */
export async function fetchSheetData(sheetName: SheetName) {
  const gid = SHEET_GIDS[sheetName];
  const url = `https://docs.google.com/spreadsheets/d/e/${SHEET_BASE_ID}/pub?gid=${gid}&output=csv`;

  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to fetch ${sheetName}: ${response.statusText}`);
    }

    const csv = await response.text();
    return parseCSV(csv);
  } catch (error) {
    console.error(`Error fetching ${sheetName}:`, error);
    return [];
  }
}

/**
 * Parse CSV text into an array of objects
 */
function parseCSV(csv: string) {
  const lines = csv.trim().split("\n");
  if (lines.length < 2) return [];

  // Parse header
  const headers = parseCSVLine(lines[0]);

  // Parse rows
  const data = lines.slice(1).map((line) => {
    const values = parseCSVLine(line);
    const obj: Record<string, string> = {};
    headers.forEach((header, index) => {
      obj[header] = values[index] || "";
    });
    return obj;
  });

  return data;
}

/**
 * Parse a single CSV line, handling quoted values
 */
function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = "";
  let insideQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    const nextChar = line[i + 1];

    if (char === '"') {
      if (insideQuotes && nextChar === '"') {
        // Escaped quote
        current += '"';
        i++;
      } else {
        // Toggle quote state
        insideQuotes = !insideQuotes;
      }
    } else if (char === "," && !insideQuotes) {
      // End of field
      result.push(current.trim());
      current = "";
    } else {
      current += char;
    }
  }

  result.push(current.trim());
  return result;
}

/**
 * Fetch all sheet data at once
 */
export async function fetchAllSheets() {
  const [offers, categories, items, contact] = await Promise.all([
    fetchSheetData("Offers"),
    fetchSheetData("MenuCategories"),
    fetchSheetData("MenuItems"),
    fetchSheetData("Contact"),
  ]);

  return {
    offers,
    categories,
    items,
    contact,
  };
}
