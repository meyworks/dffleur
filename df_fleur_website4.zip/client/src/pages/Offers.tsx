import { useEffect, useState } from "react";
import Layout from "@/components/Layout";
import { fetchSheetData } from "@/lib/gsheet";
import { Calendar, Tag } from "lucide-react";

/**
 * Offers & News Page
 * Design: Grid layout with featured cards, minimal luxury styling
 */

interface Offer {
  ID: string;
  Title: string;
  Description: string;
  Type: string;
  ImageUrl: string;
  StartDate: string;
  EndDate: string;
  Status: string;
}

export default function Offers() {
  const [offers, setOffers] = useState<Offer[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "news" | "offer">("all");

  useEffect(() => {
    const loadOffers = async () => {
      try {
        const data = await fetchSheetData("Offers");
        setOffers((data as any) as Offer[]);
      } catch (error) {
        console.error("Error loading offers:", error);
      } finally {
        setLoading(false);
      }
    };

    loadOffers();
  }, []);

  const filteredOffers = offers.filter((offer) => {
    if (filter === "all") return true;
    return offer.Type?.toLowerCase() === filter.toLowerCase();
  });

  return (
    <Layout>
      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-gradient-to-b from-muted to-background">
        <div className="container text-center space-y-6">
          <span className="text-gold-accent text-sm font-semibold tracking-widest uppercase">
            Latest Updates
          </span>
          <h1 className="text-5xl md:text-6xl font-bold">
            News & Offers
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Stay updated with our latest news, special offers, and exclusive experiences at DF FLEUR.
          </p>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-12 bg-background sticky top-20 z-40 border-b border-border">
        <div className="container">
          <div className="flex flex-wrap gap-3">
            {["all", "news", "offer"].map((type) => (
              <button
                key={type}
                onClick={() => setFilter(type as any)}
                className={`px-6 py-2 rounded-sm font-semibold transition-all duration-200 capitalize ${
                  filter === type
                    ? "bg-accent text-accent-foreground shadow-luxury"
                    : "bg-muted text-foreground hover:bg-muted/80"
                }`}
              >
                {type === "all" ? "All" : type === "news" ? "News" : "Offers"}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Offers Grid */}
      <section className="py-20 md:py-32 bg-background">
        <div className="container">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div
                  key={i}
                  className="h-96 bg-muted rounded-sm animate-pulse"
                />
              ))}
            </div>
          ) : filteredOffers.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-lg text-muted-foreground">
                No offers available at the moment.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredOffers.map((offer, index) => (
                <OfferCard key={offer.ID || index} offer={offer} />
              ))}
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
}

/**
 * Offer Card Component
 */
function OfferCard({ offer }: { offer: Offer }) {
  return (
    <div className="bg-card border border-border rounded-sm shadow-luxury overflow-hidden hover:shadow-luxury-lg transition-all duration-300 hover:-translate-y-1 group">
      {/* Image */}
      <div className="relative h-48 overflow-hidden bg-muted">
        {offer.ImageUrl ? (
          <img
            src={offer.ImageUrl}
            alt={offer.Title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground">
            No Image
          </div>
        )}

        {/* Type Badge */}
        <div className="absolute top-4 right-4 flex items-center gap-1 bg-accent text-accent-foreground px-3 py-1 rounded-full text-xs font-semibold">
          <Tag className="w-3 h-3" />
          {offer.Type}
        </div>
      </div>

      {/* Content */}
      <div className="p-6 space-y-4">
        <div>
          <h3 className="text-xl font-bold mb-2">{offer.Title}</h3>
          <p className="text-sm text-muted-foreground line-clamp-3">
            {offer.Description}
          </p>
        </div>

        {/* Date Info */}
        {offer.StartDate && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground border-t border-border pt-4">
            <Calendar className="w-4 h-4" />
            <span>
              {new Date(offer.StartDate).toLocaleDateString("en-US", {
                month: "short",
                day: "numeric",
                year: "numeric",
              })}
            </span>
          </div>
        )}

        {/* Status */}
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-muted-foreground">
            Status
          </span>
          <span className="text-xs font-semibold text-green-600 bg-green-50 px-3 py-1 rounded-full">
            {offer.Status || "Active"}
          </span>
        </div>
      </div>
    </div>
  );
}
