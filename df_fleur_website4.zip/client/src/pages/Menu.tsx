import { useEffect, useState } from "react";
import Layout from "@/components/Layout";
import { fetchSheetData } from "@/lib/gsheet";
import { ChevronDown } from "lucide-react";

/**
 * Menu Page with Interactive Flipping Cards
 * Design: 3D flip animation on hover/click, luxury card design
 */

interface MenuItem {
  ID: string;
  Category: string;
  Name: string;
  Description: string;
  Price: string;
  ImageUrl: string;
  Status: string;
}

interface MenuCategory {
  Categories: string;
}

export default function Menu() {
  const [categories, setCategories] = useState<string[]>([]);
  const [items, setItems] = useState<MenuItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [flipped, setFlipped] = useState<Set<string>>(new Set());

  useEffect(() => {
    const loadMenuData = async () => {
      try {
        const [categoriesData, itemsData] = await Promise.all([
          fetchSheetData("MenuCategories"),
          fetchSheetData("MenuItems"),
        ]);

        const categoryList = categoriesData
          .map((c: any) => c.Categories)
          .filter(Boolean);
        setCategories(categoryList);
        setItems((itemsData as any) as MenuItem[]);

        if (categoryList.length > 0) {
          setSelectedCategory(categoryList[0]);
        }
      } catch (error) {
        console.error("Error loading menu:", error);
      } finally {
        setLoading(false);
      }
    };

    loadMenuData();
  }, []);

  const filteredItems = items.filter(
    (item) => item.Category === selectedCategory
  );

  const toggleFlip = (id: string) => {
    const newFlipped = new Set(flipped);
    if (newFlipped.has(id)) {
      newFlipped.delete(id);
    } else {
      newFlipped.add(id);
    }
    setFlipped(newFlipped);
  };

  return (
    <Layout>
      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-gradient-to-b from-muted to-background">
        <div className="container text-center space-y-6">
          <span className="text-gold-accent text-sm font-semibold tracking-widest uppercase">
            Our Selection
          </span>
          <h1 className="text-5xl md:text-6xl font-bold">
            Explore Our Menu
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover our carefully curated selection of premium dishes, beverages, and culinary experiences.
          </p>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-12 bg-background sticky top-20 z-40 border-b border-border">
        <div className="container">
          <div className="flex flex-wrap gap-3">
            {loading ? (
              <div className="flex gap-3">
                {[1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    className="h-10 w-24 bg-muted rounded-sm animate-pulse"
                  />
                ))}
              </div>
            ) : (
              categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-6 py-2 rounded-sm font-semibold transition-all duration-200 ${
                    selectedCategory === category
                      ? "bg-accent text-accent-foreground shadow-luxury"
                      : "bg-muted text-foreground hover:bg-muted/80"
                  }`}
                >
                  {category}
                </button>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Menu Items Grid */}
      <section className="py-20 md:py-32 bg-background">
        <div className="container">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div
                  key={i}
                  className="h-96 bg-muted rounded-sm animate-pulse"
                />
              ))}
            </div>
          ) : filteredItems.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-lg text-muted-foreground">
                No items available in this category.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredItems.map((item) => (
                <MenuCard
                  key={item.ID}
                  item={item}
                  isFlipped={flipped.has(item.ID)}
                  onFlip={() => toggleFlip(item.ID)}
                />
              ))}
            </div>
          )}
        </div>
      </section>
    </Layout>
  );
}

/**
 * Interactive Menu Card with 3D Flip Animation
 */
function MenuCard({
  item,
  isFlipped,
  onFlip,
}: {
  item: MenuItem;
  isFlipped: boolean;
  onFlip: () => void;
}) {
  return (
    <div
      className="h-96 cursor-pointer perspective"
      onClick={onFlip}
      style={{
        perspective: "1000px",
      }}
    >
      <div
        className="relative w-full h-full transition-transform duration-500"
        style={{
          transformStyle: "preserve-3d",
          transform: isFlipped ? "rotateY(180deg)" : "rotateY(0deg)",
        }}
      >
        {/* Front Side - Image */}
        <div
          className="absolute w-full h-full bg-card rounded-sm shadow-luxury overflow-hidden"
          style={{
            backfaceVisibility: "hidden",
          }}
        >
          {item.ImageUrl ? (
            <img
              src={item.ImageUrl}
              alt={item.Name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center">
              <span className="text-muted-foreground">No Image</span>
            </div>
          )}

          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col justify-end p-6 text-cream-white">
            <h3 className="text-2xl font-bold mb-2">{item.Name}</h3>
            <p className="text-sm text-cream-white/80 line-clamp-2">
              {item.Description}
            </p>
          </div>

          {/* Flip Indicator */}
          <div className="absolute top-4 right-4 bg-accent text-accent-foreground px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1">
            <ChevronDown className="w-3 h-3" />
            Flip
          </div>
        </div>

        {/* Back Side - Details */}
        <div
          className="absolute w-full h-full bg-card rounded-sm shadow-luxury p-6 flex flex-col justify-between"
          style={{
            backfaceVisibility: "hidden",
            transform: "rotateY(180deg)",
          }}
        >
          <div className="space-y-4">
            <div>
              <h3 className="text-2xl font-bold mb-2">{item.Name}</h3>
              <span className="text-xs font-semibold text-accent bg-accent/10 px-3 py-1 rounded-full inline-block">
                {item.Category}
              </span>
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold text-sm text-muted-foreground">
                Description
              </h4>
              <p className="text-sm text-foreground">{item.Description}</p>
            </div>
          </div>

          <div className="space-y-3 border-t border-border pt-4">
            {item.Price && (
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-muted-foreground">
                  Price
                </span>
                <span className="text-lg font-bold text-accent">
                  {item.Price}
                </span>
              </div>
            )}

            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-muted-foreground">
                Status
              </span>
              <span className="text-sm font-semibold text-green-600">
                {item.Status}
              </span>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                onFlip();
              }}
              className="w-full mt-4 py-2 bg-accent text-accent-foreground rounded-sm font-semibold hover:shadow-lg transition-all duration-200"
            >
              Back
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
