import { useEffect, useState } from "react";
import { Link } from "wouter";
import Layout from "@/components/Layout";
import { fetchSheetData } from "@/lib/gsheet";
import { ChevronRight } from "lucide-react";

/**
 * Home/Landing Page
 * Design: Luxury minimalism with asymmetric layout
 * - Hero section with premium imagery
 * - Featured offers section
 * - Call-to-action sections
 */
export default function Home() {
  const [offers, setOffers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadOffers = async () => {
      try {
        const data = await fetchSheetData("Offers");
        // Get only the first 3 offers for the homepage
        setOffers(data.slice(0, 3));
      } catch (error) {
        console.error("Error loading offers:", error);
      } finally {
        setLoading(false);
      }
    };

    loadOffers();
  }, []);

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative h-screen flex items-center overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('/manus-storage/hero_background_3bc377ca.png')`,
          }}
        />

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-transparent" />

        {/* Content */}
        <div className="relative container z-10 max-w-2xl">
          <div className="space-y-6 animate-fade-in">
            <div className="inline-block">
              <span className="text-gold-accent text-sm font-semibold tracking-widest uppercase">
                Welcome to Elegance
              </span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold text-cream-white leading-tight">
              Discover the Art of Refined Dining
            </h1>

            <p className="text-lg md:text-xl text-cream-white/90 max-w-lg">
              Experience premium cuisine and exceptional coffee culture in Cairo's most sophisticated dining destination.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Link href="/menu">
                <a className="btn-luxury inline-flex items-center justify-center gap-2">
                  Explore Menu
                  <ChevronRight className="w-4 h-4" />
                </a>
              </Link>
              <Link href="/contact">
                <a className="btn-luxury-outline inline-flex items-center justify-center gap-2">
                  Reserve Now
                  <ChevronRight className="w-4 h-4" />
                </a>
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce">
          <div className="w-6 h-10 border-2 border-cream-white/50 rounded-full flex items-start justify-center p-2">
            <div className="w-1 h-2 bg-cream-white/50 rounded-full animate-pulse" />
          </div>
        </div>
      </section>

      {/* Featured Offers Section */}
      <section className="py-20 md:py-32 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
            {/* Left: Text */}
            <div className="space-y-6">
              <div>
                <span className="text-gold-accent text-sm font-semibold tracking-widest uppercase">
                  Latest News
                </span>
                <h2 className="text-4xl md:text-5xl mt-2">
                  What's New at DF FLEUR
                </h2>
              </div>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Stay updated with our latest offerings, special events, and exclusive experiences. Every cup tells a story.
              </p>
              <Link href="/offers">
                <a className="inline-flex items-center gap-2 text-accent font-semibold hover:gap-3 transition-all">
                  View All News & Offers
                  <ChevronRight className="w-5 h-5" />
                </a>
              </Link>
            </div>

            {/* Right: Featured Offers Cards */}
            <div className="space-y-4">
              {loading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div
                      key={i}
                      className="h-24 bg-muted rounded-sm animate-pulse"
                    />
                  ))}
                </div>
              ) : (
                offers.map((offer, index) => (
                  <div
                    key={index}
                    className="p-6 bg-card border border-border rounded-sm shadow-luxury hover:shadow-luxury-lg transition-all duration-300 hover:-translate-y-1"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-lg">{offer.Title}</h3>
                      <span className="text-xs font-semibold text-accent bg-accent/10 px-3 py-1 rounded-full">
                        {offer.Type}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {offer.Description}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Coffee Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('/manus-storage/coffee_hero_25371217.png')`,
          }}
        />

        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-l from-black/70 via-black/50 to-transparent" />

        {/* Content */}
        <div className="relative container z-10 max-w-2xl ml-auto">
          <div className="space-y-6 text-cream-white">
            <span className="text-gold-accent text-sm font-semibold tracking-widest uppercase">
              Coffee Culture
            </span>

            <h2 className="text-4xl md:text-5xl font-bold leading-tight">
              Every Cup Tells a Story
            </h2>

            <p className="text-lg text-cream-white/90 max-w-lg">
              Immerse yourself in our premium coffee selection, expertly crafted by our master baristas. From morning espresso to afternoon indulgence.
            </p>

            <Link href="/menu">
              <a className="btn-luxury inline-flex items-center justify-center gap-2">
                Explore Beverages
                <ChevronRight className="w-4 h-4" />
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Call-to-Action Section */}
      <section className="py-20 md:py-32 bg-deep-charcoal text-cream-white">
        <div className="container text-center space-y-8">
          <div className="space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold">
              Ready for an Unforgettable Experience?
            </h2>
            <p className="text-lg text-cream-white/80 max-w-2xl mx-auto">
              Reserve your table or visit us for a premium dining and coffee experience in the heart of Heliopolis.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Link href="/contact">
              <a className="btn-luxury inline-flex items-center justify-center gap-2">
                Get In Touch
                <ChevronRight className="w-4 h-4" />
              </a>
            </Link>
            <a
              href="https://maps.app.goo.gl/7VynE7MCGKN9WkDS9"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-luxury-outline inline-flex items-center justify-center gap-2 text-cream-white border-cream-white hover:bg-cream-white/10"
            >
              View Location
              <ChevronRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </section>
    </Layout>
  );
}
