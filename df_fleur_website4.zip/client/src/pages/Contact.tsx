import { useEffect, useState } from "react";
import Layout from "@/components/Layout";
import { fetchSheetData } from "@/lib/gsheet";
import { Phone, MapPin, Clock, Mail, Facebook, Instagram } from "lucide-react";

/**
 * Contact Page
 * Design: Luxury contact information with map and contact form
 */

interface ContactInfo {
  Name: string;
  WhatsApp: string;
  Phone: string;
  Address: string;
  OpeningHours: string;
  MapUrl: string;
  FacebookUrl: string;
  InstagramUrl: string;
}

export default function Contact() {
  const [contactInfo, setContactInfo] = useState<ContactInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const loadContact = async () => {
      try {
        const data = await fetchSheetData("Contact");
        if (data.length > 0) {
          setContactInfo((data[0] as any) as ContactInfo);
        }
      } catch (error) {
        console.error("Error loading contact info:", error);
      } finally {
        setLoading(false);
      }
    };

    loadContact();
  }, []);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, this would send to a backend
    console.log("Form submitted:", formData);
    setSubmitted(true);
    setTimeout(() => {
      setFormData({ name: "", email: "", phone: "", message: "" });
      setSubmitted(false);
    }, 3000);
  };

  if (loading) {
    return (
      <Layout>
        <section className="py-20 md:py-32 bg-muted">
          <div className="container text-center">
            <div className="h-12 w-48 bg-muted rounded-sm animate-pulse mx-auto mb-4" />
            <div className="h-8 w-96 bg-muted rounded-sm animate-pulse mx-auto" />
          </div>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-gradient-to-b from-muted to-background">
        <div className="container text-center space-y-6">
          <span className="text-gold-accent text-sm font-semibold tracking-widest uppercase">
            Get In Touch
          </span>
          <h1 className="text-5xl md:text-6xl font-bold">
            Contact Us
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            We'd love to hear from you. Reach out to us for reservations, inquiries, or just to say hello.
          </p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-20 md:py-32 bg-background">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Left: Contact Details */}
            <div className="space-y-8">
              <div>
                <h2 className="text-3xl font-bold mb-8">
                  {contactInfo?.Name || "DF FLEUR"}
                </h2>

                {/* Address */}
                {contactInfo?.Address && (
                  <div className="flex gap-4 mb-6">
                    <MapPin className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-1">Address</h3>
                      <p className="text-muted-foreground">
                        {contactInfo.Address}
                      </p>
                    </div>
                  </div>
                )}

                {/* Phone */}
                {contactInfo?.Phone && (
                  <div className="flex gap-4 mb-6">
                    <Phone className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-1">Phone</h3>
                      <a
                        href={`tel:${contactInfo.Phone}`}
                        className="text-accent hover:underline"
                      >
                        {contactInfo.Phone}
                      </a>
                    </div>
                  </div>
                )}

                {/* WhatsApp */}
                {contactInfo?.WhatsApp && (
                  <div className="flex gap-4 mb-6">
                    <Phone className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-1">WhatsApp</h3>
                      <a
                        href={`https://wa.me/${contactInfo.WhatsApp}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-accent hover:underline"
                      >
                        +{contactInfo.WhatsApp}
                      </a>
                    </div>
                  </div>
                )}

                {/* Opening Hours */}
                {contactInfo?.OpeningHours && (
                  <div className="flex gap-4 mb-6">
                    <Clock className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-1">Opening Hours</h3>
                      <p className="text-muted-foreground">
                        {contactInfo.OpeningHours}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Social Links */}
              <div className="space-y-4 border-t border-border pt-8">
                <h3 className="font-semibold">Follow Us</h3>
                <div className="flex gap-4">
                  {contactInfo?.FacebookUrl && (
                    <a
                      href={contactInfo.FacebookUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-3 bg-muted rounded-sm hover:bg-accent hover:text-accent-foreground transition-colors"
                      aria-label="Facebook"
                    >
                      <Facebook className="w-5 h-5" />
                    </a>
                  )}
                  {contactInfo?.InstagramUrl && (
                    <a
                      href={contactInfo.InstagramUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-3 bg-muted rounded-sm hover:bg-accent hover:text-accent-foreground transition-colors"
                      aria-label="Instagram"
                    >
                      <Instagram className="w-5 h-5" />
                    </a>
                  )}
                </div>
              </div>

              {/* Map Link */}
              {contactInfo?.MapUrl && (
                <a
                  href={contactInfo.MapUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-luxury inline-flex items-center justify-center gap-2 w-full"
                >
                  <MapPin className="w-4 h-4" />
                  View on Map
                </a>
              )}
            </div>

            {/* Right: Contact Form */}
            <div className="bg-card border border-border rounded-sm p-8 shadow-luxury">
              <h2 className="text-2xl font-bold mb-6">Send us a Message</h2>

              {submitted ? (
                <div className="bg-green-50 border border-green-200 text-green-800 p-4 rounded-sm text-center">
                  <p className="font-semibold">Thank you for your message!</p>
                  <p className="text-sm mt-1">
                    We'll get back to you as soon as possible.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Name */}
                  <div>
                    <label htmlFor="name" className="block text-sm font-semibold mb-2">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-sm focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent"
                      placeholder="Your name"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label htmlFor="email" className="block text-sm font-semibold mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-sm focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent"
                      placeholder="your@email.com"
                    />
                  </div>

                  {/* Phone */}
                  <div>
                    <label htmlFor="phone" className="block text-sm font-semibold mb-2">
                      Phone (Optional)
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-border rounded-sm focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent"
                      placeholder="Your phone number"
                    />
                  </div>

                  {/* Message */}
                  <div>
                    <label htmlFor="message" className="block text-sm font-semibold mb-2">
                      Message
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      required
                      rows={5}
                      className="w-full px-4 py-2 border border-border rounded-sm focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent resize-none"
                      placeholder="Your message..."
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    className="btn-luxury w-full"
                  >
                    Send Message
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      {contactInfo?.MapUrl && (
        <section className="py-20 md:py-32 bg-muted">
          <div className="container">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-2">Find Us</h2>
              <p className="text-muted-foreground">
                Visit us at our location in Heliopolis, Cairo
              </p>
            </div>

            <div className="w-full h-96 rounded-sm overflow-hidden shadow-luxury">
              <iframe
                src={`${contactInfo.MapUrl.replace("maps.app.goo.gl", "maps.google.com")}`}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen={true}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </section>
      )}
    </Layout>
  );
}
